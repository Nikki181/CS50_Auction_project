from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("create", views.create, name="create"),
    path("submit",views.submit,name="submit"),
    path("listing-page/<int:listing_id>", views.listing_page, name="listing page"),
    path("create-bid/<int:listing_id>", views.create_bid, name="create bid"),
    path("watchlist-action/<int:listing_id>", views.watchlist_action, name="watchlist action"),
    path("close-listing/<int:listing_id>", views.close_listing, name="close listing"),
    path("add-comment/<int:listing_id>", views.add_comment, name="add comment"),
    path("watchlist-page", views.watchlist_page, name="watchlist page"),
    path("categories", views.all_categories, name="all categories"),
    path("categories/<str:category>", views.category_details, name='category details'),
]
