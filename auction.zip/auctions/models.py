from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext as _
from django.core.validators import MaxValueValidator, MinValueValidator

class User(AbstractUser):
    pass

class Listing(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_listings",default=1)
    title=models.CharField(max_length=64)
    description=models.CharField(max_length=64)
    bid=models.IntegerField(blank=True, null=True)
    imageurl=models.CharField(max_length=64,default=None,blank=True,null=True)
    category=models.CharField(max_length=64)
    watchlist_users = models.ManyToManyField(User, blank=True, related_name="watchlist_items")
    closed = models.BooleanField(default=False)

    def current_price(self):        
         return max([bid.value_offer for bid in self.bids.all()]+[self.bid])

    def no_of_bids(self):        
        return len(self.bids.all())

    def current_winning_bidder(self):
        return self.bids.get(value_offer=self.current_price()).user if self.no_of_bids() > 0 else None

    def __str__(self):
        return f'{self.title} by {self.user}: {self.description}'

class Bids(models.Model):
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="bids")
    value_offer = models.DecimalField(max_digits=8, decimal_places=2)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bids_made")

    def clean(self):
        # Don't allow value offer to be lower than current price of listing
        print(self.value_offer)
        print(self.listing.current_price())
        if self.value_offer and self.listing.current_price():
            if self.value_offer <= self.listing.current_price():
                raise ValidationError({'value_offer': _('Please make sure your bid value is higher than the current '
                                                        'price of the item!')})

    def __str__(self):
        return f"{self.user} offers to pay ${self.value_offer} for the listing: {self.listing}"


class Comments(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name="comments")
    content = models.CharField(max_length=2048)
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="comments")

    def __str__(self):
        return f"{self.author} says {self.content} for listing: {self.listing}"

