from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render,redirect
from django.urls import reverse
from .models import Listing,Bids,Comments
from .models import User
from django.contrib import messages

def index(request):
    items =Listing.objects.filter(closed=False)[::-1]
    return render(request, "auctions/index.html",{
        'title': "Active Listings",
        "items":items
    })

def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")

@login_required
def create(request):
    return render(request, "auctions/create.html")

@login_required
def submit(request):
    if request.method == 'POST':
        assert request.user.is_authenticated
        newlisting=Listing()
        newlisting.user = request.user
        newlisting.title=request.POST.get('title')
        newlisting.description=request.POST.get('description')
        newlisting.bid=request.POST.get('bid')
        newlisting.category=request.POST.get('category')
        if request.POST.get('imageurl'):
            newlisting.imageurl=request.POST.get('imageurl')
        else :
            newlisting.imageurl = "https://wallpaperaccess.com/full/1605486.jpg"
       
        newlisting.save()           
        return redirect('index')

    else:
        return render(request, "auctions/login.html")

def listing_page(request, listing_id):
    listing = Listing.objects.get(pk=listing_id)
    print(listing.closed)
    if request.user.is_authenticated:
        is_watch_list = request.user.watchlist_items.filter(pk=listing_id).exists()

        # if bid form was passed to us already, we likely want to produce an error from create bid route.
        # if not bid_form:
        #     bid_form = BidForm()

        is_mine = listing.user == request.user
    else:
        is_watch_list = None
        is_mine = None

    return render(request, "auctions/listing.html", {
        'listing': listing,
        'is_mine': is_mine,
        'is_watchlist': is_watch_list
    })

def create_bid(request,listing_id):
    if request.method == "POST":
        try:            
            currentprice=request.POST.get('currentprice')
            bidval=request.POST.get('value_offer')
            bid=Bids()
            bid.listing = Listing.objects.get(pk=listing_id)
            bid.value_offer=request.POST.get('value_offer')
            bid.user=request.user
            if bidval>currentprice:
                bid.save()
                print("success")
                messages.success(request, "Thanks, your bid has been successfully made!")
        except:            
            print("Fail")            
            messages.error(request,"Please make sure your bid value is higher than the current price of the item!")
            # return listing_page(request, listing_id)
          
    return HttpResponseRedirect(reverse("listing page", args=(listing_id,)))

@login_required
def watchlist_action(request, listing_id):
    if request.method == "POST":
        assert request.user.is_authenticated
        user = request.user
        listing = Listing.objects.get(pk=listing_id)
        if user.watchlist_items.filter(pk=listing_id).exists():
            user.watchlist_items.remove(listing)
        else:
            user.watchlist_items.add(listing)
    return HttpResponseRedirect(reverse("listing page", args=(listing_id,)))

@login_required
def watchlist_page(request):
    assert request.user.is_authenticated
    return render(request, "auctions/index.html", {
        'items': request.user.watchlist_items.all()[::-1],
        'title': "Watchlist Items"
    })

@login_required
def close_listing(request,listing_id):
    if request.method == "POST":
        assert request.user.is_authenticated
        listing = Listing.objects.get(pk=listing_id)      
        if request.user == listing.user:
            listing.closed = True
            listing.save()
    return HttpResponseRedirect(reverse("listing page", args=(listing_id,)))

@login_required
def add_comment(request,listing_id):
    if request.method == "POST":
        assert request.user.is_authenticated
        listing = Listing.objects.get(pk=listing_id)
        comment=Comments()
        comment.author=request.user
        comment.content = request.POST['comment']
        comment.listing=listing
        comment.save()
    return HttpResponseRedirect(reverse("listing page", args=(listing_id,)))

def all_categories(request):
    categories = list(set([listing.category for listing in Listing.objects.all() if listing.category]))
    print(categories)
    return render(request, "auctions/categories.html", {
        'categories': categories
    })

def category_details(request, category):
    return render(request, "auctions/index.html", {
        'items': Listing.objects.filter(closed=False, category=category),
        'title': f'Active listings under "{category}"'
    })

# superuser: nikkishah
# email: nikkishah.1801@gmail.com
# password: jes^@086


# nikki1801
# nikkishah.1801@gmail.com
# 12345678