from django.contrib import admin

# Register your models here.
from auctions.models import Listing, Comments, Bids, User

admin.site.register(Listing)
admin.site.register(Comments)
admin.site.register(Bids)
admin.site.register(User)